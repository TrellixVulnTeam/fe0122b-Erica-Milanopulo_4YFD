import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';
import { Users } from 'src/app/models/users';
import {UserService} from 'src/app/service/user.service';

@Component({
  selector: 'app-singolo',
  templateUrl: './singolo.component.html',
  styleUrls: ['./singolo.component.scss']
})
export class SingoloComponent implements OnInit {

  user!: Users | undefined;

  constructor(private router: ActivatedRoute, private utenti: UserService) { }

  ngOnInit(): void {
    this.router.params.subscribe(params => {
     const id = +params['id'];
     this.user = this.utenti.recuperaUno(id);
    })
  }

}
