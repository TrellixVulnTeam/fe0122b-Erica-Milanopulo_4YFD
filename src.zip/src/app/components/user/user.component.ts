import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { Users } from 'src/app/models/users'
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  users!: Users[]

  constructor(private utenti: UserService) { }

  ngOnInit(): void {
    this.users = this.utenti.recuperaTutti();
  }

}
