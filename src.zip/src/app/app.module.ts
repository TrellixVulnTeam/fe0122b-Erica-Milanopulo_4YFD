import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Route, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { ActivePostsComponent } from './components/active-posts/active-posts.component';
import { InactivePostsComponent } from './components/inactive-posts/inactive-posts.component';
import { CardComponent } from './components/card/card.component';
import { UserComponent } from './components/user/user.component';
import { ColoraDirective } from './directives/colora.directive';
import { SingoloComponent } from './components/singolo/singolo.component';
import { DetailsComponent } from './components/details/details.component';

const routes: Route[] = [
  { path: '', component: HomeComponent },
  { path: 'active-posts', component: ActivePostsComponent },
  { path: 'inactive-posts', component: InactivePostsComponent },
  {
    path: 'user',
    component: UserComponent,
    children: [{
      path: ':id',
      component: SingoloComponent,
    }]
  },
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    ActivePostsComponent,
    InactivePostsComponent,
    CardComponent,
    UserComponent,
    ColoraDirective,
    SingoloComponent,
    DetailsComponent,
  ],
  imports: [BrowserModule, RouterModule.forRoot(routes)],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
