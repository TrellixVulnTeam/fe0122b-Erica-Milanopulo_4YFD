import { Injectable } from '@angular/core';
import { Users } from '../models/users'

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private users: Users[] =[
    {
      id: 1,
      nome: 'Erica',
      ruolo: 'admin',
      email: 'erica@gmail.com'
    },
    {
      id: 2,
      nome: 'Mirko',
      ruolo: 'admin',
      email: 'mirko@gmail.com'
    },
    {
      id: 3,
      nome: 'Roberto',
      ruolo: 'user',
      email: 'roberto@gmail.com'
    },
    {
      id: 4,
      nome: 'Camilla',
      ruolo: 'user',
      email: 'cami@gmail.com'
    },
  ]
  constructor() { }

  recuperaTutti(){
    return this.users
  }

  recuperaUno(idUser:number){
    return this.users.find((user) => user.id === idUser)
  }
}
