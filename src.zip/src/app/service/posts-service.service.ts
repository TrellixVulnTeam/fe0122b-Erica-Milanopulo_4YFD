import { Post } from "../models/post";
import { Injectable } from '@angular/core';

let posts: Post[] = [
  {
  id: 1,
  title: 'Post 1',
  body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris magna mi, convallis et commodo et, dapibus et lacus. Integer non tempus lorem, nec porta massa. Phasellus sed ultrices nunc. Praesent facilisis purus lacus. Vestibulum ac lectus ut turpis placerat facilisis. Sed aliquam leo non massa eleifend congue. In sit amet dui pharetra, iaculis augue pulvinar, ornare neque. Mauris magna enim, scelerisque vel dictum a, pellentesque at urna. Integer at lobortis nibh, quis maximus lacus. Nullam non ligula ligula. Ut molestie mi in odio venenatis, vitae laoreet nisl eleifend.',
  active: true,
  type: 'notizie'
},
{
  id: 2,
  title: 'Post 2',
  body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris magna mi, convallis et commodo et, dapibus et lacus. Integer non tempus lorem, nec porta massa. Phasellus sed ultrices nunc. Praesent facilisis purus lacus. Vestibulum ac lectus ut turpis placerat facilisis. Sed aliquam leo non massa eleifend congue.Integer at lobortis nibh, quis maximus lacus. Nullam non ligula ligula. Ut molestie mi in odio venenatis, vitae laoreet nisl eleifend.',
  active: false,
  type: 'politica'
},
{
  id: 3,
  title: 'Post 3',
  body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris magna mi, convallis et commodo et, dapibus et lacus. Integer non tempus lorem, nec porta massa. Phasellus sed ultrices nunc. Praesent facilisis purus lacus. Vestibulum ac lectus ut turpis placerat facilisis. Sed aliquam leo non massa eleifend congue. In sit amet dui pharetra, iaculis augue pulvinar, ornare neque. Mauris magna enim, scelerisque vel dictum a, pellentesque at urna. Integer at lobortis nibh, quis maximus lacus. Nullam non ligula ligula. Ut molestie mi in odio venenatis, vitae laoreet nisl eleifend.',
  active: true,
  type: 'sport'
},
{
  id: 4,
  title: 'Post 4',
  body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris magna mi, convallis et commodo et, dapibus et lacus. Integer non tempus lorem, nec porta massa. Phasellus sed ultrices nunc. Praesent facilisis purus lacus. Vestibulum ac lectus ut turpis placerat facilisis. Sed aliquam leo non massa eleifend congue. In sit amet dui pharetra, iaculis augue pulvinar, ornare neque. Mauris magna enim, scelerisque vel dictum a, pellentesque at urna. Integer at lobortis nibh, quis maximus lacus. Nullam non ligula ligula. Ut molestie mi in odio venenatis, vitae laoreet nisl eleifend.',
  active: false,
  type: 'notizie'
}
]

export function recupera() {
  return posts;
}

//Partial rende tutte le proprietà opzionali
export function aggiorna(data: Partial<Post>, id: number) {

//gli dici di prendere id di post e se è uguale all'id che gli arriva cambia contenuto di post con quello di data, sennò post
posts = posts.map(post => post.id == id?{...post,...data}: post);

//find restituisce il valore del primo elemento dell'array che rispetta quel valore, sennò restituisce undefined
return posts.find(post => post.id == id) as Post; //è necessario indicare as Post perchè abbiamo dei partial

}
