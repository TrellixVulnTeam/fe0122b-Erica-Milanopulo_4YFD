export interface Users {
  id: number,
  nome: string,
  ruolo: 'admin' | 'user',
  email: string
}
